The logo of GDevelop are the property of Florian Rival. You may use them to represent GDevelop in blog articles, newspaper, articles and website referring to GDevelop.

Contact Florian Rival for questions about GDevelop: https://www.linkedin.com/in/florianrival

GDevelop links:
* Website: https://gdevelop-app.com/
* Download links: https://gdevelop-app.com/download
* Online editor: https://editor.gdevelop-app.com/
* Documentation: http://wiki.compilgames.net/doku.php/gdevelop5/start
* Game showcase: https://gdevelop-app.com/games-showcase

Community links:
* Forums: https://forum.gdevelop-app.com/
* Discord community: https://discord.gg/rjdYHvj
* GitHub: https://github.com/4ian/GDevelop
* Twitter: https://twitter.com/GDevelopApp
* Facebook: https://www.facebook.com/GDevelopApp/